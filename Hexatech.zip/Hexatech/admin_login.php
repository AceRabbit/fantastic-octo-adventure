<?php
session_start();

// DB connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "peso";
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $stmt = $conn->prepare("SELECT * FROM users WHERE username=? AND role='admin' LIMIT 1");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 1) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['role'] = "admin";
            $_SESSION['username'] = $row['username'];
            header("Location: admin_dashboard.php");
            exit;
        } else {
            $message = "❌ Invalid password!";
        }
    } else {
        $message = "❌ Only Admin accounts can log in here!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin Login</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    font-family: 'Inter', sans-serif;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background: #1f1f2e;
    color: #f0f0f0;
}
.login-container {
    width: 380px;
    padding: 40px 35px;
    background: #2c2c3e;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.6);
    text-align: center;
}
.login-container h2 {
    margin-bottom: 30px;
    font-size: 28px;
    font-weight: 600;
    color: #f5f5f5;
}
.input-group {
    position: relative;
    margin: 18px 0;
}
.input-group i.lock-icon {
    position: absolute;
    top: 50%;
    left: 12px;
    transform: translateY(-50%);
    color: #888;
}
input {
    width: 100%;
    padding: 12px 38px 12px 38px;
    border-radius: 8px;
    border: 1px solid #444;
    background: #1f1f2e;
    color: #f0f0f0;
    font-size: 15px;
    outline: none;
    transition: 0.3s;
}
input:focus {
    border-color: #5a67f2;
    box-shadow: 0 0 10px rgba(90,103,242,0.5);
}
.show-pass {
    position: absolute;
    top: 50%;
    right: 12px;
    transform: translateY(-50%);
    cursor: pointer;
    color: #888;
}
button {
    width: 100%;
    padding: 12px;
    margin-top: 20px;
    border-radius: 8px;
    border: none;
    background: #5a67f2;
    color: #fff;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: 0.3s;
}
button:hover {
    background: #434fcf;
    box-shadow: 0 5px 15px rgba(90,103,242,0.4);
}
.back-btn {
    display: inline-block;
    margin-top: 15px;
    padding: 10px 18px;
    border-radius: 8px;
    background: #4b5563;
    color: #fff;
    text-decoration: none;
    font-size: 14px;
    font-weight: 500;
    transition: 0.3s;
}
.back-btn:hover {
    background: #374151;
}
.message {
    margin-top: 15px;
    color: #ff6b6b;
    font-weight: 500;
    font-size: 14px;
}
footer {
    position: absolute;
    bottom: 20px;
    font-size: 13px;
    color: #aaa;
    width: 100%;
    text-align: center;
}
</style>
</head>
<body>

<div class="login-container">
    <h2>Admin Login</h2>
    <form method="POST">
        <div class="input-group">
            <i class="fas fa-user lock-icon"></i>
            <input type="text" name="username" placeholder="Admin Username" required>
        </div>
        <div class="input-group">
            <i class="fas fa-lock lock-icon"></i>
            <input type="password" name="password" id="password" placeholder="Password" required>
            <i class="fas fa-eye show-pass" id="togglePass"></i>
        </div>
        <button type="submit">Login</button>
    </form>
    <?php if($message): ?>
        <p class="message"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>
    <!-- Back button -->
    <a href="index.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back</a>
</div>

<footer>
    &copy; 2025 PESO Admin Panel
</footer>

<script>
const togglePass = document.getElementById('togglePass');
const passwordInput = document.getElementById('password');

togglePass.addEventListener('click', () => {
    if(passwordInput.type === 'password') {
        passwordInput.type = 'text';
        togglePass.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        togglePass.classList.replace('fa-eye-slash', 'fa-eye');
    }
});
</script>

</body>
</html>
