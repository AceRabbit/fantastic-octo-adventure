<?php
// post_job.php
session_start();

// DB connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "peso";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// ✅ Ensure jobs table exists with correct columns
$createTable = "
CREATE TABLE IF NOT EXISTS jobs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    department VARCHAR(255) NOT NULL,
    location VARCHAR(255) NOT NULL,
    salary VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    date_posted TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;
";
$conn->query($createTable);

// Insert job when form is submitted
$message = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $department = $_POST['department'];
    $location = $_POST['location'];
    $salary = $_POST['salary'];
    $description = $_POST['description'];

    $stmt = $conn->prepare("INSERT INTO jobs (title, department, location, salary, description) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $title, $department, $location, $salary, $description);

    if ($stmt->execute()) {
        $message = "Job posted successfully!";
    } else {
        $message = "Error: " . $conn->error;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Post a Job - PESO</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Inter', sans-serif;
      background: #f4f6f9;
      padding: 50px;
    }
    .container {
      max-width: 600px;
      margin: auto;
      background: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    h2 { margin-bottom: 20px; text-align: center; }
    form input, form textarea {
      width: 100%;
      padding: 12px;
      margin: 10px 0;
      border: 1px solid #ddd;
      border-radius: 8px;
    }
    form button {
      width: 100%;
      padding: 12px;
      background: #2d4d73;
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
    }
    form button:hover { background: #1a334d; }
    .message {
      text-align: center; color: green;
      font-weight: bold; margin-bottom: 15px;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>Post a Job</h2>
    <?php if ($message): ?>
      <p class="message"><?= htmlspecialchars($message) ?></p>
    <?php endif; ?>
    <form method="POST">
      <input type="text" name="title" placeholder="Job Title" required>
      <input type="text" name="department" placeholder="Department" required>
      <input type="text" name="location" placeholder="Location" required>
      <input type="text" name="salary" placeholder="Salary" required>
      <textarea name="description" rows="5" placeholder="Job Description" required></textarea>
      <button type="submit">Post Job</button>
    </form>
  </div>
</body>
</html>
