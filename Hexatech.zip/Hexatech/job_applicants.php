<?php
session_start();

// DB connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "peso";
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get job_id from URL
if (!isset($_GET['job_id'])) {
    die("No job selected.");
}
$job_id = intval($_GET['job_id']);

// Fetch job details
$stmt = $conn->prepare("SELECT * FROM jobs WHERE id = ?");
$stmt->bind_param("i", $job_id);
$stmt->execute();
$job = $stmt->get_result()->fetch_assoc();

if (!$job) {
    die("Job not found.");
}

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $resume = $_POST['resume'];

    $stmt = $conn->prepare("INSERT INTO applications (job_id, name, email, resume) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("isss", $job_id, $name, $email, $resume);

    if ($stmt->execute()) {
        echo "<script>alert('Application submitted successfully!'); window.location='user.php';</script>";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Apply - <?= htmlspecialchars($job['title']) ?></title>
  <style>
    body { font-family: Arial, sans-serif; background: #f4f6f9; padding: 30px; }
    .container { background: white; padding: 20px; border-radius: 10px; max-width: 500px; margin: auto; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
    h2 { margin-bottom: 15px; }
    label { display: block; margin-top: 10px; font-weight: bold; }
    input, textarea { width: 100%; padding: 10px; margin-top: 5px; border-radius: 5px; border: 1px solid #ccc; }
    button { margin-top: 15px; padding: 10px 20px; background: #2d4d73; color: white; border: none; border-radius: 5px; cursor: pointer; }
    button:hover { background: #1a334d; }
  </style>
</head>
<body>
  <div class="container">
    <h2>Apply for <?= htmlspecialchars($job['title']) ?></h2>
    <p><strong>Location:</strong> <?= htmlspecialchars($job['location']) ?></p>
    <p><strong>Salary:</strong> <?= htmlspecialchars($job['salary']) ?></p>
    <p><?= nl2br(htmlspecialchars($job['description'])) ?></p>

    <form method="post">
      <label for="name">Full Name</label>
      <input type="text" name="name" required>

      <label for="email">Email</label>
      <input type="email" name="email" required>

      <label for="resume">Resume / Cover Letter</label>
      <textarea name="resume" rows="5" required></textarea>

      <button type="submit">Submit Application</button>
    </form>
  </div>
</body>
</html>
