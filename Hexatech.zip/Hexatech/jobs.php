<?php
// jobs.php
session_start();

// DB connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "peso";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch all jobs
$result = $conn->query("SELECT * FROM jobs");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Available Jobs</title>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <style>
    body {
      font-family: 'Inter', sans-serif;
      background: #f4f6f9;
      margin: 0;
      padding: 0;
    }
    .container {
      max-width: 900px;
      margin: 40px auto;
      padding: 20px;
    }
    .job-card {
      background: #fff;
      padding: 20px;
      margin-bottom: 20px;
      border-radius: 10px;
      box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    h2 {
      color: #2d4d73;
    }
    .btn {
      display: inline-block;
      padding: 10px 16px;
      background: #2d4d73;
      color: #fff;
      border-radius: 6px;
      text-decoration: none;
      transition: 0.3s;
    }
    .btn:hover {
      background: #1a334d;
    }
  </style>
</head>
<body>
  <div class="container">
    <h1>Available Jobs</h1>
    <?php while ($job = $result->fetch_assoc()): ?>
      <div class="job-card">
        <h2><?= htmlspecialchars($job['title']) ?></h2>
        <p><strong>Location:</strong> <?= htmlspecialchars($job['location']) ?></p>
        <p><strong>Salary:</strong> <?= htmlspecialchars($job['salary']) ?></p>
        <p><strong>Department:</strong> <?= htmlspecialchars($job['department']) ?></p>
        <p><?= nl2br(htmlspecialchars($job['description'])) ?></p>
        <a href="apply.php?job_id=<?= $job['id'] ?>" class="btn">Apply Now</a>
      </div>
    <?php endwhile; ?>
  </div>
</body>
</html>
