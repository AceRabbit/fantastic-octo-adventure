<?php
session_start();
require 'includes/db.inc.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $password = $_POST["password"];
    $role = $_POST["role"];

   
    $stmt = $conn->prepare("SELECT id, username, password, role FROM accounts WHERE username = ? AND role = ?");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);  
    }

    $stmt->bind_param("ss", $username, $role);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $result->num_rows === 1) {
        $row = $result->fetch_assoc();

        if (password_verify($password, $row["password"])) {
            $_SESSION["username"] = $row["username"];
            $_SESSION["role"] = $row["role"];
            $_SESSION["id"] = $row["id"];

           
            if ($row["role"] === "admin") {
                header("Location: about.php");
                exit();
            } else {
                header("Location: user.php");
                exit();
            }
        } else {
            echo "<script>alert('Incorrect password'); window.location.href = 'login.php';</script>";
        }
    } else {
        echo "<script>alert('Account not found or role mismatch'); window.location.href = 'login.php';</script>";
    }

    $stmt->close();
    $conn->close();
} else {
    header("Location: login.php");
    exit();
}
?>
