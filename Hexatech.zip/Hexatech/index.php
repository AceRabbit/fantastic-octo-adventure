<?php
// index.php
session_start();

// DB connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "peso";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch jobs (latest first)
$result = $conn->query("SELECT * FROM jobs ORDER BY date_posted DESC LIMIT 6");

// Staff data array (no MySQL needed)
$staffMembers = [
    [
        "name" => "Jane Doe",
        "position" => "PESO Manager",
        "email" => "jane.doe@example.com",
        "phone" => "09171234567",
        "photo" => "images/jane.jpg",
        "bio" => "Jane oversees all PESO operations and ensures employment programs run smoothly."
    ],
    [
        "name" => "John Smith",
        "position" => "Employment Officer",
        "email" => "john.smith@example.com",
        "phone" => "09179876543",
        "photo" => "images/john.jpg",
        "bio" => "John helps job seekers find local and overseas employment opportunities."
    ],
    [
        "name" => "Maria Santos",
        "position" => "Career Counselor",
        "email" => "maria.santos@example.com",
        "phone" => "09173456789",
        "photo" => "images/maria.jpg",
        "bio" => "Maria provides counseling sessions to guide applicants in career planning."
    ],
    [
        "name" => "Carlos Reyes",
        "position" => "Administrative Staff",
        "email" => "carlos.reyes@example.com",
        "phone" => "09175678901",
        "photo" => "images/carlos.jpg",
        "bio" => "Carlos manages administrative tasks and ensures smooth office operations."
    ],
    [
        "name" => "Anna Lopez",
        "position" => "Job Placement Coordinator",
        "email" => "anna.lopez@example.com",
        "phone" => "09172345678",
        "photo" => "images/anna.jpg",
        "bio" => "Anna coordinates job placements and follows up with employers and applicants."
    ]
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>PESO - Job Portal</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Playfair+Display:wght@600&display=swap" rel="stylesheet">
<style>
/* --- Global --- */
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Inter', sans-serif; background: #f4f6f9; color: #333; }

/* --- Navbar --- */
nav {
  position: fixed; top: 0; width: 100%;
  background: #1a3c6e;
  padding: 15px 60px;
  display: flex; justify-content: space-between; align-items: center;
  z-index: 1000;
  box-shadow: 0 3px 8px rgba(0,0,0,0.2);
}
nav .logo {
  color: white; font-size: 24px; font-weight: bold;
  text-transform: uppercase; font-family: 'Playfair Display', serif;
  letter-spacing: 1px;
}
nav ul { list-style: none; display: flex; gap: 30px; }
nav ul li a {
  text-decoration: none; color: white; font-size: 15px;
  text-transform: uppercase; transition: 0.3s; font-weight: 600;
}
nav ul li a:hover { color: #ffcccb; }

/* --- Hero --- */
.hero {
  background: url('Peso.png') no-repeat center center/cover;
  height: 100vh;
  display: flex; justify-content: center; align-items: center;
  text-align: center; color: white; position: relative;
}
.hero::after {
  content: ""; position: absolute; inset: 0;
  background: rgba(0, 0, 0, 0.55);
}
.hero-content { position: relative; z-index: 1; max-width: 700px; padding: 20px; }
.hero-content h1 { font-size: 52px; margin-bottom: 20px; font-family: 'Playfair Display', serif; }
.hero-content p { font-size: 18px; margin-bottom: 30px; }
.hero-content a {
  padding: 14px 40px; background: #c82333; color: white;
  text-decoration: none; font-weight: bold;
  border-radius: 30px; transition: 0.3s;
  font-size: 16px; display: inline-block;
}
.hero-content a:hover { background: #1a3c6e; transform: translateY(-2px); }

/* --- Job Section --- */
.jobs { padding: 80px 10%; text-align: center; background: #ffffff; }
.jobs h2 {
  font-size: 34px; margin-bottom: 40px; font-family: 'Playfair Display', serif; 
  color: #1a3c6e; border-bottom: 3px solid #c82333; display: inline-block; padding-bottom: 8px;
}
.job-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 30px; }
.job-card {
  background: #f9f9f9; padding: 25px; border-radius: 8px;
  border: 1px solid #ddd; box-shadow: 0 3px 6px rgba(0,0,0,0.08);
  transition: 0.3s; text-align: left;
}
.job-card:hover { transform: translateY(-5px); box-shadow: 0 5px 12px rgba(0,0,0,0.15); }
.job-card h3 { margin-bottom: 10px; font-size: 20px; color: #c82333; }
.job-card p { font-size: 14px; margin-bottom: 15px; color: #555; line-height: 1.5; }
.job-card a.apply {
  text-decoration: none; color: white; background: #1a3c6e;
  padding: 10px 20px; border-radius: 20px; font-size: 14px;
  transition: 0.3s; font-weight: 600;
}
.job-card a.apply:hover { background: #c82333; }
.see-more {
  color:#1a3c6e; font-weight:600; margin-left:5px; cursor:pointer;
  text-decoration:none; font-size:13px;
}
.see-more:hover { color:#c82333; text-decoration:underline; }

/* --- About / Staff --- */
.about { padding: 80px 10%; background: #1a3c6e; color: white; text-align: center; }
.about h2 { font-size: 32px; margin-bottom: 20px; font-family: 'Playfair Display', serif; }
.about p { max-width: 700px; margin: auto; line-height: 1.7; font-size: 15px; }

/* Staff Grid */
.staff-grid {
  display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: 20px; margin-top: 30px; justify-items: center;
}
.staff-card {
  background: white; padding: 15px; border-radius: 10px; text-align: center;
  cursor: pointer; transition: transform 0.3s, box-shadow 0.3s;
}
.staff-card img {
  width: 100px; height: 100px; border-radius: 50%; object-fit: cover;
  margin-bottom: 10px; transition: transform 0.3s;
}
.staff-card img:hover { transform: scale(1.1); }
.staff-card h4 { margin-bottom: 5px; color:#1a3c6e; }
.staff-card p { font-size: 14px; color:#555; }
.staff-card:hover { transform: translateY(-5px); box-shadow: 0 5px 15px rgba(0,0,0,0.2); }

/* Modal */
.modal {
  display: none; position: fixed; z-index: 2000;
  left: 0; top: 0; width: 100%; height: 100%; overflow: auto;
  background-color: rgba(0,0,0,0); transition: background-color 0.3s ease;
}
.modal.show { background-color: rgba(0,0,0,0.6); }
.modal-content {
  background-color: white; margin: 10% auto; padding: 30px;
  border-radius: 10px; max-width: 500px; text-align: center;
  position: relative; transform: scale(0.7); opacity: 0;
  transition: transform 0.3s ease, opacity 0.3s ease;
}
.modal.show .modal-content { transform: scale(1); opacity: 1; }
.modal .close {
  position: absolute; top: 10px; right: 20px; font-size: 28px; font-weight: bold;
  cursor: pointer; color: #333;
}

/* --- Footer --- */
footer { background: #c82333; color: white; text-align: center; padding: 20px; font-size: 14px; }
</style>
</head>
<body>

<!-- Navbar -->
<nav>
  <div class="logo">PESO</div>
  <ul>
    <li><a href="#">Home</a></li>
    <li><a href="#about">About</a></li>
    <li><a href="#jobs">Job Hiring</a></li>
    <li><a href="admin_login.php">Admin</a></li>
    <li><a href="login.php">Login</a></li>
  </ul>
</nav>

<!-- Hero Section -->
<section class="hero">
  <div class="hero-content">
    <h1>Find Your Next Job with PESO</h1>
    <p>Where opportunities meet ambition — discover jobs you never knew existed and start a journey that could change your life</p>
    <a href="#jobs">Browse Jobs</a>
  </div>
</section>

<!-- Job Section -->
<section class="jobs" id="jobs">
  <h2>Featured Job Openings</h2>
  <div class="job-grid">
    <?php if ($result && $result->num_rows > 0): ?>
      <?php while($row = $result->fetch_assoc()): ?>
        <div class="job-card">
          <h3><?= htmlspecialchars($row['title']) ?></h3>
          <p>
            <strong>Department:</strong> <?= htmlspecialchars($row['department']) ?><br>
            <strong>Location:</strong> <?= htmlspecialchars($row['location']) ?><br>
            <strong>Salary:</strong> ₱<?= htmlspecialchars($row['salary']) ?><br>
            <strong>Posted:</strong> <?= date("M d, Y", strtotime($row['date_posted'])) ?>
          </p>
          <?php 
            $shortDesc = substr($row['description'], 0, 120);
            $isLong = strlen($row['description']) > 120;
          ?>
          <p class="job-desc">
            <?= nl2br(htmlspecialchars($shortDesc)) ?>
            <?php if ($isLong): ?>
              <span class="more-text" style="display:none;"><?= nl2br(htmlspecialchars(substr($row['description'],120))) ?></span>
              <a href="javascript:void(0)" class="see-more">See More</a>
            <?php endif; ?>
          </p>
          <a href="login.php" class="apply">Apply Now</a>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p>No job postings available at the moment.</p>
    <?php endif; ?>
  </div>
</section>

<!-- About / Staff Section -->
<section class="about" id="about">
  <h2>About PESO</h2>
  <p>
    The Public Employment Service Office (PESO) is a non-fee charging multi-employment service facility
    that ensures the provision of timely employment facilitation services to the people. 
    We help local job seekers and those seeking opportunities abroad connect with employers.
  </p>

  <h3 style="margin-top:50px;">Meet Our Staff</h3>
  <div class="staff-grid">
    <?php foreach ($staffMembers as $index => $staff): ?>
      <div class="staff-card" onclick="openModal('modal-<?= $index ?>')">
        <img src="<?= $staff['photo'] ?>" alt="<?= $staff['name'] ?>">
        <h4><?= $staff['name'] ?></h4>
        <p><?= $staff['position'] ?></p>
      </div>

      <!-- Modal -->
      <div id="modal-<?= $index ?>" class="modal">
        <div class="modal-content">
          <span class="close" onclick="closeModal('modal-<?= $index ?>')">&times;</span>
          <img src="<?= $staff['photo'] ?>" alt="<?= $staff['name'] ?>" style="width:150px; border-radius:50%;">
          <h3><?= $staff['name'] ?></h3>
          <p><strong>Position:</strong> <?= $staff['position'] ?></p>
          <p><strong>Email:</strong> <?= $staff['email'] ?></p>
          <p><strong>Phone:</strong> <?= $staff['phone'] ?></p>
          <p><?= $staff['bio'] ?></p>
        </div>
      </div>
    <?php endforeach; ?>
  </div>
</section>

<!-- Footer -->
<footer>
  <p>© 2025 PESO Job Portal | Developed for Employment Opportunities</p>
</footer>

<script>
document.addEventListener("DOMContentLoaded", function() {
  // See more toggle
  document.querySelectorAll(".see-more").forEach(btn => {
    btn.addEventListener("click", function() {
      let moreText = this.previousElementSibling;
      if (moreText.style.display === "none") {
        moreText.style.display = "inline";
        this.textContent = "See Less";
      } else {
        moreText.style.display = "none";
        this.textContent = "See More";
      }
    });
  });
});

// Modal functions with animation
function openModal(id) {
  let modal = document.getElementById(id);
  modal.style.display = "block";
  setTimeout(() => { modal.classList.add('show'); }, 10); 
}
function closeModal(id) {
  let modal = document.getElementById(id);
  modal.classList.remove('show');
  setTimeout(() => { modal.style.display = "none"; }, 300); 
}

// Close modal when clicking outside
window.onclick = function(event) {
  document.querySelectorAll('.modal').forEach(modal => {
    if (event.target == modal) closeModal(modal.id);
  });
}
</script>

</body>
</html>
