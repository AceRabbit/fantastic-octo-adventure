<?php
session_start();

// DB connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "peso";
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Include PDF Parser (install via composer: composer require smalot/pdfparser)
require 'vendor/autoload.php';
use Smalot\PdfParser\Parser;

$job_id = $_GET['job_id'] ?? 0;
$job = null;
$message = "";
$recommended_jobs = [];

// Fetch job details
if ($job_id) {
    $stmt = $conn->prepare("SELECT * FROM jobs WHERE id = ?");
    $stmt->bind_param("i", $job_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $job = $result->fetch_assoc();
    $stmt->close();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $job) {
    $full_name = $_POST['fullname'];
    $email = $_POST['email'];
    $resumeFile = $_FILES['resume'];
    $resumePath = "";
    $resumeText = "";

    if ($resumeFile['error'] == 0) {
        $allowed = ['pdf', 'doc', 'docx'];
        $ext = strtolower(pathinfo($resumeFile['name'], PATHINFO_EXTENSION));

        if (in_array($ext, $allowed) && $resumeFile['size'] <= 2 * 1024 * 1024) {
            if (!is_dir("uploads/resumes")) mkdir("uploads/resumes", 0777, true);
            $resumePath = "uploads/resumes/" . time() . "_" . basename($resumeFile['name']);
            move_uploaded_file($resumeFile['tmp_name'], $resumePath);

            // Parse PDF
            if ($ext === "pdf") {
                $parser = new Parser();
                $pdf = $parser->parseFile($resumePath);
                $resumeText = strtolower($pdf->getText());
            }
            // TODO: Add support for DOC/DOCX parsing

        } else {
            $message = "❌ Invalid file type or size. Only PDF, DOC, DOCX under 2MB allowed.";
        }
    }

    if ($resumePath) {
        $stmt = $conn->prepare("
            INSERT INTO applications (job_id, full_name, email, resume, date_applied) 
            VALUES (?, ?, ?, ?, NOW())
        ");
        $stmt->bind_param("isss", $job_id, $full_name, $email, $resumePath);

        if ($stmt->execute()) {
            $message = "✅ Application submitted successfully!";

            // --- Resume to Job Matching ---
            if ($resumeText) {
                $allJobs = $conn->query("SELECT * FROM jobs");
                while ($row = $allJobs->fetch_assoc()) {
                    $jobText = strtolower($row['title'] . " " . $row['description']);
                    similar_text($resumeText, $jobText, $percent);
                    if ($percent > 5) { // threshold
                        $row['match'] = round($percent, 2);
                        $recommended_jobs[] = $row;
                    }
                }
                // Sort by match %
                usort($recommended_jobs, function($a, $b) {
                    return $b['match'] <=> $a['match'];
                });
            }

        } else {
            $message = "❌ Error: " . $conn->error;
        }
        $stmt->close();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Apply for Job</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f5f5f5; padding: 20px; }
        .container { max-width: 600px; margin: auto; background: #fff; padding: 20px; border-radius: 8px; }
        input, button { width: 100%; padding: 10px; margin: 10px 0; }
        .message { margin: 15px 0; color: green; font-weight: bold; }
        .error { color: red; }
        .recommended { margin-top: 20px; }
        .recommended ul { list-style: none; padding: 0; }
        .recommended li { background: #f0f0f0; padding: 10px; margin: 5px 0; border-radius: 5px; }
        a { text-decoration: none; color: blue; }
    </style>
</head>
<body>
<div class="container">
    <?php if ($job): ?>
        <h2>Apply for <?= htmlspecialchars($job['title']) ?></h2>
        <p><strong>Location:</strong> <?= htmlspecialchars($job['location']) ?></p>
        <p><strong>Description:</strong> <?= htmlspecialchars($job['description']) ?></p>

        <?php if ($message): ?>
            <div class="message"><?= $message ?></div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <input type="text" name="fullname" placeholder="Full Name" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="file" name="resume" accept=".pdf,.doc,.docx" required>
            <button type="submit">Submit Application</button>
        </form>
    <?php else: ?>
        <p>No job selected.</p>
    <?php endif; ?>

    <?php if (!empty($recommended_jobs)): ?>
        <div class="recommended">
            <h3>🔥 Recommended Jobs Based on Your Resume</h3>
            <ul>
                <?php foreach ($recommended_jobs as $rjob): ?>
                    <li>
                        <strong><?= htmlspecialchars($rjob['title']) ?></strong> 
                        (<?= htmlspecialchars($rjob['location']) ?>) 
                        - Match: <?= $rjob['match'] ?>%
                        <a href="apply.php?job_id=<?= $rjob['id'] ?>">Apply</a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
</div>
</body>
</html>
