<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') exit;

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "peso";
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$job_id = isset($_GET['job_id']) ? intval($_GET['job_id']) : 0;

// Fetch messages sent by admin to applicants of this job
$messages = $conn->query("
    SELECT m.*, a.full_name 
    FROM messages m
    INNER JOIN applications a ON m.recipient_email = a.email
    WHERE a.job_id = $job_id
    ORDER BY m.sent_at DESC
");

if ($messages && $messages->num_rows > 0) {
    while ($msg = $messages->fetch_assoc()) {
        echo '<div class="message">';
        echo '<p><strong>To:</strong> ' . htmlspecialchars($msg['full_name']) . ' (' . htmlspecialchars($msg['recipient_email']) . ')</p>';
        echo '<p><strong>Subject:</strong> ' . htmlspecialchars($msg['subject']) . '</p>';
        echo '<p><strong>Message:</strong> ' . nl2br(htmlspecialchars($msg['message'])) . '</p>';
        echo '<p><small>Sent at: ' . $msg['sent_at'] . '</small></p>';
        echo '</div>';
    }
} else {
    echo '<p style="text-align:center; color:#555;">No messages sent yet.</p>';
}
?>
