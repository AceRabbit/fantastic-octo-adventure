<?php 
session_start();

// DB connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "peso";
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    $fullname = trim($_POST['fullname']);
    $email = trim($_POST['email']);
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $role = $_POST['role'];

    if ($password !== $confirm_password) {
        $message = "❌ Passwords do not match!";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        if ($role === "admin") {
            $check = $conn->query("SELECT * FROM users WHERE role='admin'");
            if ($check->num_rows > 0) {
                $message = "❌ Only one admin account is allowed!";
            } else {
                $stmt = $conn->prepare("INSERT INTO users (fullname, email, username, password, role) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("sssss", $fullname, $email, $username, $hashed_password, $role);
                $stmt->execute();
                $message = "✅ Admin registered successfully!";
            }
        } else { // applicant
            $stmt = $conn->prepare("INSERT INTO users (fullname, email, username, password, role) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $fullname, $email, $username, $hashed_password, $role);
            if ($stmt->execute()) {
                $message = "✅ Applicant registered successfully!";
            } else {
                $message = "❌ Username or email already exists!";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Sign Up</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    font-family: 'Inter', sans-serif;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background: #1f1f2e;
    color: #f0f0f0;
}
.container {
    width: 400px;
    padding: 40px 35px;
    background: #2c2c3e;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.6);
    text-align: center;
}
h2 {
    font-size: 28px;
    font-weight: 600;
    margin-bottom: 30px;
}
.input-group {
    position: relative;
    margin: 18px 0;
}
.input-group i.left {
    position: absolute;
    top: 50%;
    left: 12px;
    transform: translateY(-50%);
    color: #888;
}
input, select {
    width: 100%;
    padding: 12px 40px;
    border-radius: 8px;
    border: 1px solid #444;
    background: #1f1f2e;
    color: #f0f0f0;
    font-size: 15px;
    outline: none;
    transition: 0.3s;
}
input:focus, select:focus {
    border-color: #5a67f2;
    box-shadow: 0 0 10px rgba(90,103,242,0.5);
}
.show-pass {
    position: absolute;
    top: 50%;
    right: 12px;
    transform: translateY(-50%);
    cursor: pointer;
    color: #888;
}
button {
    width: 100%;
    padding: 12px;
    margin-top: 20px;
    border-radius: 8px;
    border: none;
    background: #5a67f2;
    color: #fff;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: 0.3s;
}
button:hover {
    background: #434fcf;
    box-shadow: 0 5px 15px rgba(90,103,242,0.4);
}
.message {
    margin-top: 15px;
    color: #ff6b6b;
    font-weight: 500;
    font-size: 14px;
}
a {
    color: #ddd;
    display: block;
    text-align: center;
    margin-top: 10px;
    text-decoration: none;
}
a:hover { text-decoration: underline; }
</style>
</head>
<body>

<div class="container">
    <h2>Create Account</h2>
    <form method="POST">
        <div class="input-group">
            <i class="fas fa-user left"></i>
            <input type="text" name="fullname" placeholder="Full Name" required>
        </div>
        <div class="input-group">
            <i class="fas fa-envelope left"></i>
            <input type="email" name="email" placeholder="Email Address" required>
        </div>
        <div class="input-group">
            <i class="fas fa-user-circle left"></i>
            <input type="text" name="username" placeholder="Username" required>
        </div>
        <div class="input-group">
            <i class="fas fa-lock left"></i>
            <input type="password" name="password" id="password" placeholder="Password" required>
            <i class="fas fa-eye show-pass" id="togglePass"></i>
        </div>
        <div class="input-group">
            <i class="fas fa-lock left"></i>
            <input type="password" name="confirm_password" id="confirm_password" placeholder="Confirm Password" required>
            <i class="fas fa-eye show-pass" id="toggleConfirmPass"></i>
        </div>
        <div class="input-group">
            <select name="role" required>
                <option value="">-- Select Role --</option>
                <option value="admin">Admin</option>
                <option value="applicant">Applicant</option>
            </select>
        </div>
        <button type="submit">Sign Up</button>
    </form>

    <p class="message"><?= $message ?></p>
    <a href="login.php">Already have an account? Login</a>
</div>

<script>
const togglePass = document.getElementById('togglePass');
const passwordInput = document.getElementById('password');
togglePass.addEventListener('click', () => {
    if(passwordInput.type === 'password') {
        passwordInput.type = 'text';
        togglePass.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        togglePass.classList.replace('fa-eye-slash', 'fa-eye');
    }
});

const toggleConfirmPass = document.getElementById('toggleConfirmPass');
const confirmInput = document.getElementById('confirm_password');
toggleConfirmPass.addEventListener('click', () => {
    if(confirmInput.type === 'password') {
        confirmInput.type = 'text';
        toggleConfirmPass.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        confirmInput.type = 'password';
        toggleConfirmPass.classList.replace('fa-eye-slash', 'fa-eye');
    }
});
</script>

</body>
</html>
