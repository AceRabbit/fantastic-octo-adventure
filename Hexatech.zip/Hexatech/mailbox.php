<?php
session_start();
if(!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "peso";
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$username = $_SESSION['username'];

// Handle reply submission
$message_status = "";
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['reply_message'], $_POST['subject'])) {
    $subject = $conn->real_escape_string($_POST['subject']);
    $message = $conn->real_escape_string($_POST['reply_message']);
    $stmt = $conn->prepare("INSERT INTO messages (sender_email, recipient_email, subject, message, sent_at) VALUES (?, 'admin@peso.com', ?, ?, NOW())");
    $stmt->bind_param("sss", $username, $subject, $message);
    if($stmt->execute()) $message_status = "✅ Reply sent to admin.";
    else $message_status = "❌ Failed to send reply.";
}

// Fetch messages between this user and admin
$stmt = $conn->prepare("
    SELECT * FROM messages 
    WHERE (sender_email='admin@peso.com' AND recipient_email=?) 
       OR (sender_email=? AND recipient_email='admin@peso.com') 
    ORDER BY sent_at DESC
");
$stmt->bind_param("ss", $username, $username);
$stmt->execute();
$result = $stmt->get_result();
$mailbox = [];
while($row = $result->fetch_assoc()) $mailbox[] = $row;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>PESO - Mailbox</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
<style>
body { font-family: 'Inter', sans-serif; background: #f4f6f9; margin:0; }
nav { position: fixed; top:0; width:100%; background: rgba(0,0,0,0.8); padding:15px 60px; display:flex; justify-content:space-between; color:white; z-index:1000; }
.container { max-width:900px; margin:120px auto 40px auto; padding:20px; background:#fff; border-radius:12px; box-shadow:0 8px 24px rgba(0,0,0,0.1);}
h2 { text-align:center; margin-bottom:20px; }
.message-item { border-bottom:1px solid #eee; padding:15px; }
.message-item.admin { background:#f0f8ff; }
.message-item.user { background:#fef9f9; }
.message-item h4 { margin-bottom:5px; font-size:18px; }
.message-item p { font-size:15px; color:#555; margin-bottom:5px; }
.message-item span { font-size:13px; color:#999; }
.reply-form textarea, .reply-form button { width:100%; padding:10px; margin:5px 0; border-radius:6px; }
.reply-form button { background:#0984e3; color:#fff; font-weight:bold; cursor:pointer; }
.reply-form button:hover { background:#74b9ff; }
</style>
</head>
<body>
<nav>
  <div>PESO</div>
  <div>
    <a href="index.php" style="color:white; margin-right:15px;">Home</a>
    <a href="logout.php" style="color:white;">Logout (<?= htmlspecialchars($_SESSION['username']) ?>)</a>
  </div>
</nav>
<div class="container">
    <h2>Mailbox</h2>
    <?php if(empty($mailbox)): ?>
        <p style="text-align:center;">No messages yet.</p>
    <?php else: ?>
        <?php foreach($mailbox as $msg): ?>
            <div class="message-item <?= $msg['sender_email'] === 'admin@peso.com' ? 'admin' : 'user'; ?>">
                <h4><?= htmlspecialchars($msg['subject']) ?></h4>
                <p><?= nl2br(htmlspecialchars($msg['message'])) ?></p>
                <span>From: <?= htmlspecialchars($msg['sender_email']) ?> | <?= date("M d, Y H:i", strtotime($msg['sent_at'])) ?></span>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- Reply Form -->
    <div class="reply-form">
        <h3>Reply to Admin</h3>
        <form method="POST">
            <input type="text" name="subject" placeholder="Subject" required>
            <textarea name="reply_message" rows="4" placeholder="Type your reply here..." required></textarea>
            <button type="submit">Send Reply</button>
        </form>
        <?php if($message_status) echo "<p>$message_status</p>"; ?>
    </div>
</div>
</body>
</html>
