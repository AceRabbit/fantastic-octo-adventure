<?php
session_start();

// --- DB connection ---
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "peso";
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// PDF parser
require_once __DIR__ . "/vendor/autoload.php";
use Smalot\PdfParser\Parser;

$recommended_jobs = [];
$message = "";
$resumePath = "";
$resumeText = "";

// --- Handle resume upload & job suggestion ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['resume'])) {
    $resume = $_FILES['resume'];

    if ($resume['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($resume['name'], PATHINFO_EXTENSION));

        // Create uploads folder if missing
        if (!is_dir("uploads/resumes")) {
            mkdir("uploads/resumes", 0777, true);
        }
        $resumePath = "uploads/resumes/" . time() . "_" . basename($resume['name']);
        move_uploaded_file($resume['tmp_name'], $resumePath);

        // --- Extract text ---
        if ($ext === "pdf") {
            $parser = new Parser();
            $pdf = $parser->parseFile($resumePath);
            $resumeText = strtolower($pdf->getText());
        } elseif ($ext === "docx") {
            $zip = new ZipArchive;
            if ($zip->open($resumePath) === TRUE) {
                $xml = $zip->getFromName("word/document.xml");
                $zip->close();
                $resumeText = strtolower(strip_tags($xml));
            }
        } elseif ($ext === "doc") {
            $resumeText = strtolower(file_get_contents($resumePath));
        }

        // --- Compare with jobs ---
        if ($resumeText) {
            $allJobs = $conn->query("SELECT * FROM jobs WHERE status='posted'");
            while ($row = $allJobs->fetch_assoc()) {
                $jobText = strtolower($row['title'] . " " . $row['description']);
                similar_text($resumeText, $jobText, $percent);

                // --- Skill matching ---
                $jobSkills = [];
                $matchedSkills = [];
                if (!empty($row['requirements'])) {
                    $jobSkills = array_map('trim', explode(',', strtolower($row['requirements'])));
                    foreach ($jobSkills as $skill) {
                        if (strpos($resumeText, $skill) !== false) {
                            $matchedSkills[] = $skill;
                        }
                    }
                }

                // --- Add skill matches to percentage ---
                $percent += count($matchedSkills) * 5;

                if ($percent > 5) { // only suggest if match > 5%
                    $row['match'] = round(min($percent, 100), 2);
                    $row['matchedSkills'] = $matchedSkills; // store matched skills
                    $recommended_jobs[] = $row;
                }
            }

            // Sort jobs by highest match %
            usort($recommended_jobs, function($a, $b) {
                return $b['match'] <=> $a['match'];
            });

            $message = "✅ Resume uploaded successfully! Recommended jobs are shown below.";
        } else {
            $message = "❌ Could not extract text from your resume.";
        }
    } else {
        $message = "❌ Error uploading resume.";
    }
}

// --- Fetch all posted jobs ---
$posted_jobs = $conn->query("SELECT * FROM jobs WHERE status='posted' ORDER BY date_posted DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>PESO - Resume Scanner</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&family=Merriweather:wght@600&display=swap" rel="stylesheet">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body { font-family: 'Inter', sans-serif; background: #f4f6f9; color: #333; }

nav { position: fixed; top: 0; width: 100%; background: #003366;
      padding: 15px 60px; display: flex; justify-content: space-between;
      align-items: center; z-index: 1000; border-bottom: 5px solid #ffcc00; }
nav .logo { color: white; font-size: 24px; font-weight: bold; font-family: 'Merriweather', serif; letter-spacing: 1px; text-transform: uppercase; }
nav ul { list-style: none; display: flex; gap: 25px; }
nav ul li a { text-decoration: none; color: white; font-size: 15px; text-transform: uppercase; font-weight: 600; transition: 0.3s; }
nav ul li a:hover { color: #ffcc00; }

.resume-upload { background: #fff; margin: 120px auto 40px; padding: 30px; border-radius: 12px; max-width: 600px;
                 text-align: center; box-shadow: 0 6px 12px rgba(0,0,0,0.1); border: 2px solid #003366; }
.resume-upload h2 { margin-bottom: 20px; color: #003366; font-family: 'Merriweather', serif; }
.resume-upload input[type="file"] { margin-bottom: 15px; }
.resume-upload button { background: #003366; color: #fff; padding: 12px 28px; border: none; border-radius: 30px;
                        cursor: pointer; font-weight: bold; font-size: 15px; transition: 0.3s; }
.resume-upload button:hover { background: #ffcc00; color: #003366; }

.alert { padding: 15px; margin: 20px auto; border-radius: 5px; max-width: 700px; text-align: center; }
.success { background: #d4edda; color: #155724; }
.error { background: #f8d7da; color: #721c24; }

.jobs { padding: 60px 10%; text-align: center; background: #ffffff; }
.jobs h2 { font-size: 28px; margin-bottom: 40px; font-family: 'Merriweather', serif; color: #003366; position: relative; }
.jobs h2::after { content: ""; width: 80px; height: 4px; background: #ffcc00; display: block; margin: 10px auto 0; }
.job-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 25px; }
.job-card { background: #fdfdfd; border: 1px solid #ddd; border-radius: 12px 12px 8px 8px;
            padding: 25px; text-align: left; box-shadow: 0 4px 8px rgba(0,0,0,0.06); transition: 0.3s; }
.job-card:hover { transform: translateY(-6px); box-shadow: 0 8px 16px rgba(0,0,0,0.12); }
.job-card h3 { margin-bottom: 12px; font-size: 20px; color: #003366; }
.job-card p { font-size: 14px; margin-bottom: 10px; color: #555; line-height: 1.5; }
.apply-btn { display: inline-block; text-decoration: none; background: #003366; color: white; padding: 10px 22px;
             border-radius: 20px; font-size: 14px; font-weight: 600; transition: 0.3s; }
.apply-btn:hover { background: #ffcc00; color: #003366; }

/* Skill tags */
.skill-tag { display:inline-block; padding:3px 8px; margin:2px; border-radius:4px; font-size:12px; color:#fff; background:#0d47a1; position: relative; }
.skill-tag.matched { background: #ffcc00; color:#003366; font-weight:bold; cursor: help; }
.skill-tag.matched::after { content: "Matched with your resume"; position: absolute; bottom: 125%; left: 50%;
    transform: translateX(-50%); background-color: #333; color: #fff; padding: 5px 8px; border-radius: 4px; font-size: 10px;
    white-space: nowrap; opacity: 0; visibility: hidden; transition: opacity 0.3s; pointer-events: none; z-index: 10; }
.skill-tag.matched:hover::after { opacity: 1; visibility: visible; }

footer { background: #003366; color: white; text-align: center; padding: 20px; font-size: 14px; border-top: 5px solid #ffcc00; margin-top: 60px; }

/* --- Resume Scanning Overlay (REALISTIC) --- */
#scanning-overlay {
    position: fixed;
    top: 0; left: 0;
    width: 100%; height: 100%;
    background: rgba(0, 30, 60, 0.95);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
    z-index: 3000;
    visibility: hidden;
    opacity: 0;
    transition: opacity 0.3s ease;
    color: #fff;
    font-family: 'Merriweather', serif;
}
#scanning-overlay.active { visibility: visible; opacity: 1; }

.resume-sheet {
    width: 60%; max-width: 500px; height: 70%;
    background: #fff;
    border-radius: 8px;
    position: relative;
    overflow: hidden;
    box-shadow: 0 0 25px rgba(0,255,100,0.4);
}
.scanner-beam {
    position: absolute;
    top: -20%;
    left: 0;
    width: 100%;
    height: 15%;
    background: rgba(0,255,100,0.25);
    box-shadow: 0 0 25px rgba(0,255,100,0.7);
    animation: scanPage 3.5s linear infinite;
}
@keyframes scanPage {
    0%   { top: -20%; }
    100% { top: 100%; }
}
.scanning-text { font-size: 20px; font-weight: bold; margin-top: 25px; text-align: center; letter-spacing: 1px; }
.progress-bar { width: 300px; height: 14px; background: #444; border-radius: 8px; margin-top: 15px; overflow: hidden; }
.progress-fill { width: 0%; height: 100%; background: linear-gradient(90deg, #00ff99, #00cc66); transition: width 0.3s ease; }
</style>
</head>
<body>

<!-- Resume Scanning Overlay -->
<div id="scanning-overlay">
  <div class="resume-sheet">
    <div class="scanner-beam"></div>
  </div>
  <div class="scanning-text">📄 Scanning Your Resume...</div>
  <div class="progress-bar"><div class="progress-fill"></div></div>
</div>

<!-- Navbar -->
<nav>
  <div class="logo">PESO</div>
  <ul>
    <li><a href="#home">Home</a></li>
    <li><a href="#jobs">Jobs</a></li>
    <li><a href="#resume">Resume Scanner</a></li>
    <li><a href="index.php">Logout</a></li>
  </ul>
</nav>

<!-- Resume Upload -->
<section class="resume-upload" id="resume">
  <h2>📄 Upload Your Resume</h2>
  <form method="POST" enctype="multipart/form-data">
      <input type="file" name="resume" accept=".pdf,.doc,.docx" required><br>
      <button type="submit">Scan Resume</button>
  </form>
</section>

<?php if ($message): ?>
  <div class="alert <?= strpos($message, '✅') !== false ? 'success' : 'error' ?>">
      <?= htmlspecialchars($message) ?>
  </div>
<?php endif; ?>

<!-- Recommended Jobs -->
<?php if (!empty($recommended_jobs)): ?>
<section class="jobs" id="jobs">
  <h2>🔥 Recommended Jobs Based on Your Resume</h2>
  <div class="job-grid">
    <?php foreach ($recommended_jobs as $rjob): ?>
      <div class="job-card">
        <h3><?= htmlspecialchars($rjob['title']) ?></h3>
        <p><strong>Location:</strong> <?= htmlspecialchars($rjob['location']) ?></p>
        <p><strong>Match:</strong> <?= $rjob['match'] ?>%</p>
        <p><?= nl2br(htmlspecialchars(substr($rjob['description'], 0, 120))) ?>...</p>

        <?php if (!empty($rjob['requirements'])): ?>
          <p><strong>Required Skills:</strong>
            <?php
              $skills = array_map('trim', explode(',', $rjob['requirements']));
              foreach ($skills as $skill) {
                  $skill = htmlspecialchars($skill);
                  $class = in_array(strtolower($skill), $rjob['matchedSkills']) ? 'skill-tag matched' : 'skill-tag';
                  echo "<span class=\"$class\">$skill</span> ";
              }
            ?>
          </p>
        <?php endif; ?>

        <a class="apply-btn" href="apply.php?job_id=<?= $rjob['id'] ?>">Apply Now</a>
      </div>
    <?php endforeach; ?>
  </div>
</section>
<?php endif; ?>

<!-- All Job Listings -->
<section class="jobs">
  <h2>Available Job Openings</h2>
  <div class="job-grid">
    <?php if ($posted_jobs && $posted_jobs->num_rows > 0): ?>
      <?php while ($row = $posted_jobs->fetch_assoc()): ?>
        <div class="job-card">
          <h3><?= htmlspecialchars($row['title']) ?></h3>
          <p><strong>Location:</strong> <?= htmlspecialchars($row['location']) ?></p>
          <p><?= nl2br(htmlspecialchars(substr($row['description'], 0, 120))) ?>...</p>

          <?php if (!empty($row['requirements'])): ?>
            <p><strong>Required Skills:</strong>
              <?php
                $skills = array_map('trim', explode(',', $row['requirements']));
                foreach ($skills as $skill) {
                    $skill = htmlspecialchars($skill);
                    echo "<span class=\"skill-tag\">$skill</span> ";
                }
              ?>
            </p>
          <?php endif; ?>

          <a class="apply-btn" href="apply.php?job_id=<?= $row['id'] ?>">Apply Now</a>
        </div>
      <?php endwhile; ?>
    <?php else: ?>
      <p>No job postings available.</p>
    <?php endif; ?>
  </div>
</section>

<footer>
  <p>&copy; <?= date('Y') ?> PESO Job Portal | Official Public Employment Service Office</p>
</footer>

<script>
// Show scanning overlay on form submit with progress bar
const form = document.querySelector(".resume-upload form");
const overlay = document.getElementById("scanning-overlay");
const progress = document.querySelector(".progress-fill");
const overlayDuration = 4; // seconds

form.addEventListener("submit", function(e) {
    e.preventDefault(); // prevent immediate submit
    overlay.classList.add("active");

    let percent = 0;
    const step = 100 / (overlayDuration * 2);
    const interval = setInterval(() => {
        percent += step;
        progress.style.width = Math.min(percent,100) + "%";
    }, 500);

    setTimeout(() => {
        clearInterval(interval);
        form.submit(); // submit after effect
    }, overlayDuration * 1000);
});
</script>

</body>
</html>
