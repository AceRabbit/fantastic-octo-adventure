<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "peso";
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Add Job Posting
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['job_post'])) {
    $title = $conn->real_escape_string($_POST['title']);
    $department = $conn->real_escape_string($_POST['department']);
    $location = $conn->real_escape_string($_POST['location']);
    $description = $conn->real_escape_string($_POST['description']);
    $salary = $_POST['salary'] !== '' ? str_replace(['₱', ','], '', $_POST['salary']) : null;
    $requirements = $_POST['requirements'] !== '' ? $conn->real_escape_string($_POST['requirements']) : null;

    $conn->query("INSERT INTO jobs (title, department, description, requirements, salary, location, status, date_posted) 
                  VALUES ('$title', '$department', '$description', " . ($requirements ? "'$requirements'" : "NULL") . ", " . ($salary ? "'$salary'" : "NULL") . ", '$location', 'posted', NOW())");
    header("Location: admin_dashboard.php");
    exit;
}

// Delete Job
if (isset($_GET['delete_job_id'])) {
    $delete_id = intval($_GET['delete_job_id']);
    $conn->query("DELETE FROM jobs WHERE id = $delete_id");
    header("Location: admin_dashboard.php");
    exit;
}

// Fetch Jobs
$jobs = $conn->query("
    SELECT j.id, j.title, j.department, j.description, j.requirements, j.salary, j.location, j.date_posted, COUNT(a.id) as applicant_count
    FROM jobs j
    LEFT JOIN applications a ON j.id = a.job_id
    WHERE j.status = 'posted'
    GROUP BY j.id
    ORDER BY j.date_posted DESC
");

// Totals
$totalJobs = $conn->query("SELECT COUNT(*) as total FROM jobs WHERE status='posted'")->fetch_assoc()['total'];
$totalApplicants = $conn->query("SELECT COUNT(*) as total FROM applications")->fetch_assoc()['total'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>PESO Admin Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"/>
<style>
body { font-family: 'Inter', sans-serif; margin: 0; display: flex; height: 100vh; background: #f4f6f9; }

/* Header Bar */
.header { 
    position: fixed; top: 0; left: 240px; right: 0; height: 65px; 
    background: #0d47a1; color: #fff; 
    display: flex; align-items: center; justify-content: space-between;
    padding: 0 20px; box-shadow: 0 2px 6px rgba(0,0,0,0.2); z-index: 1000;
}
.header h1 { font-size: 18px; margin: 0; font-weight: 600; display: flex; align-items: center; }

/* Sidebar */
.sidebar { 
    width: 240px; background: #1e1e2d; color: #fff; 
    display: flex; flex-direction: column; 
    position: fixed; top: 0; bottom: 0; left: 0;
    padding-top: 80px;
}
.sidebar .logo { text-align: center; margin-bottom: 15px; }
.sidebar .logo img { 
    width: 70px; 
    height: 70px; 
    border-radius: 50%; 
    display: block; 
    margin: 0 auto 10px; 
    object-fit: cover;
}
.sidebar h2 { text-align: center; margin-bottom: 25px; font-size: 16px; font-weight: 600; color: #ffeb3b; }
.sidebar a { color: #b8c7ce; text-decoration: none; padding: 12px 20px; display: flex; align-items: center; transition: 0.3s; font-size: 14px; }
.sidebar a:hover { background: #27293d; color: #fff; border-left: 4px solid #f9a825; }
.sidebar i { margin-right: 10px; }

/* Main */
.main { flex: 1; margin-left: 240px; padding: 110px 30px 30px; overflow-y: auto; }

/* Cards */
.cards { display: flex; gap: 20px; margin-bottom: 25px; flex-wrap: wrap; }
.card { background: #fff; border-radius: 8px; padding: 20px; flex: 1 1 250px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); border-left: 6px solid #0d47a1; }
.card h3 { margin: 0 0 10px; font-size: 14px; font-weight: 600; color: #555; }
.card p { font-size: 24px; font-weight: bold; color: #0d47a1; }

/* Forms */
form input, form textarea { width: 100%; padding: 10px; margin: 8px 0; border: 1px solid #ccc; border-radius: 6px; font-size: 14px; }
form button { background: #f9a825; color: #fff; font-weight: bold; cursor: pointer; border: none; padding: 10px; border-radius: 6px; transition: 0.3s; }
form button:hover { background: #f57f17; }

/* Skill tags container */
#skills-container span { cursor: default; }

/* Job table */
.table-wrapper { background: #fff; border-radius: 8px; padding: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }
.table-wrapper h2 { margin: 0 0 10px; }
table { width: 100%; border-collapse: collapse; margin-top: 10px; }
table thead { background: #0d47a1; color: #fff; }
table th, table td { padding: 12px; font-size: 14px; text-align: left; border-bottom: 1px solid #eee; }
table tr:hover { background: #f9f9f9; }
.delete-btn { color: #e53935; font-size: 13px; text-decoration: none; }
.delete-btn:hover { text-decoration: underline; }
.view-btn { color: #0d47a1; text-decoration: none; }
.view-btn:hover { text-decoration: underline; }
.skill-tag {
    display:inline-block; padding:3px 8px; margin:2px; background:#0d47a1; color:white; border-radius:4px; font-size:12px;
}
</style>
</head>
<body>

<div class="sidebar">
    <div class="logo">
        <img src="Peso.png" alt="PESO Logo">
    </div>
    <h2>PESO Admin</h2>
    <a href="#"><i class="fas fa-tachometer-alt"></i> Dashboard</a>
    <a href="#post-job"><i class="fas fa-briefcase"></i> Post Job</a>
    <a href="#job-listings"><i class="fas fa-list"></i> Job Listings</a>
    <a href="index.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
</div>

<div class="header">
    <h1>Public Employment Service Office</h1>
    <span>Welcome, <?= htmlspecialchars($_SESSION['username']); ?></span>
</div>

<div class="main"> 
    <!-- Dashboard cards -->
    <div class="cards">
        <div class="card"><h3>Total Jobs</h3><p><?= $totalJobs ?></p></div>
        <div class="card"><h3>Total Applicants</h3><p><?= $totalApplicants ?></p></div>
    </div>

    <!-- Post Job -->
    <div class="card" id="post-job">
        <h2>Post a New Job</h2>
        <form method="POST" id="jobForm">
            <input type="hidden" name="job_post" value="1">
            <input type="text" name="title" placeholder="Job Title" required>
            <input type="text" name="department" placeholder="Department" required>
            <input type="text" name="location" placeholder="Location" required>
            <input type="text" id="salary" name="salary" placeholder="Salary (Optional)">
            <textarea name="description" placeholder="Job Description" required></textarea>

            <!-- Skill Tags Input -->
            <label>Required Skills:</label>
            <div id="skills-container" style="border:1px solid #ccc; padding:5px; border-radius:6px; min-height:40px; display:flex; flex-wrap:wrap;">
                <input type="text" id="skillInput" placeholder="Type a skill and press Enter" style="border:none; outline:none; flex:1; min-width:120px;">
            </div>
            <input type="hidden" name="requirements" id="requirements" required>

            <button type="submit">Post Job</button>
        </form>
    </div>

    <!-- Job Listings -->
    <div class="table-wrapper" id="job-listings">
        <h2>Posted Job Listings</h2>
        <table>
            <thead>
                <tr>
                    <th>Job Title</th>
                    <th>Department</th>
                    <th>Location</th>
                    <th>Salary</th>
                    <th>Skills</th>
                    <th>Date Posted</th>
                    <th>Applicants</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($jobs->num_rows > 0): ?>
                    <?php while ($job = $jobs->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($job['title']); ?></td>
                            <td><?= htmlspecialchars($job['department']); ?></td>
                            <td><?= htmlspecialchars($job['location']); ?></td>
                            <td><?= $job['salary'] ? '₱' . number_format($job['salary']) : 'Not specified'; ?></td>
                            <td>
                                <?php
                                if ($job['requirements']) {
                                    $skillsArr = explode(',', $job['requirements']);
                                    foreach ($skillsArr as $skill) {
                                        echo '<span class="skill-tag">'.htmlspecialchars(trim($skill)).'</span> ';
                                    }
                                }
                                ?>
                            </td>
                            <td><?= htmlspecialchars($job['date_posted']); ?></td>
                            <td><?= $job['applicant_count']; ?></td>
                            <td>
                                <a class="view-btn" href="view_applicants.php?job_id=<?= $job['id']; ?>">View</a> | 
                                <a class="delete-btn" href="?delete_job_id=<?= $job['id']; ?>" onclick="return confirm('Are you sure?');">Delete</a>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="8" style="text-align:center;">No jobs posted yet.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
const salaryInput = document.getElementById('salary');
if(salaryInput){
    salaryInput.addEventListener('input', function(e) {
        let value = e.target.value.replace(/[^0-9.]/g, '');
        if(value === '') return;
        let parts = value.split('.');
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        e.target.value = '₱' + parts.join('.');
    });
    salaryInput.form.addEventListener('submit', function() {
        salaryInput.value = salaryInput.value.replace(/[^0-9.]/g, '');
    });
}

// Skill tags input
const skillsContainer = document.getElementById('skills-container');
const skillInput = document.getElementById('skillInput');
const requirementsInput = document.getElementById('requirements');
let skills = [];

skillInput.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
        e.preventDefault();
        const skill = skillInput.value.trim();
        if (skill && !skills.includes(skill)) {
            skills.push(skill);
            addSkillTag(skill);
            skillInput.value = '';
            updateRequirements();
        }
    }
});

function addSkillTag(skill) {
    const tag = document.createElement('span');
    tag.textContent = skill;
    tag.style.background = '#0d47a1';
    tag.style.color = '#fff';
    tag.style.padding = '3px 8px';
    tag.style.margin = '2px';
    tag.style.borderRadius = '4px';
    tag.style.fontSize = '12px';
    tag.style.display = 'flex';
    tag.style.alignItems = 'center';

    const removeBtn = document.createElement('span');
    removeBtn.textContent = '×';
    removeBtn.style.marginLeft = '6px';
    removeBtn.style.cursor = 'pointer';
    removeBtn.addEventListener('click', function() {
        skills = skills.filter(s => s !== skill);
        skillsContainer.removeChild(tag);
        updateRequirements();
    });

    tag.appendChild(removeBtn);
    skillsContainer.insertBefore(tag, skillInput);
}

function updateRequirements() {
    requirementsInput.value = skills.join(', ');
}

document.getElementById('jobForm').addEventListener('submit', function() {
    updateRequirements();
});
</script>
</body>
</html>
