<?php
session_start();
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

$host = "localhost";
$user = "root";
$pass = "";
$dbname = "peso";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// Get job ID from query
$job_id = isset($_GET['job_id']) ? intval($_GET['job_id']) : 0;

// Fetch job details safely
$job = $conn->query("SELECT * FROM jobs WHERE id = $job_id")->fetch_assoc();
$applicants = $conn->query("SELECT * FROM applications WHERE job_id = $job_id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Applicants - <?= isset($job['title']) ? htmlspecialchars($job['title']) : 'Job'; ?></title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
<style>
    body { font-family: 'Inter', sans-serif; margin: 0; padding: 0; background: #f5f6fa; color: #2f3640; }
    h1, h2 { text-align: center; margin-bottom: 15px; font-size: 20px; }
    .container { max-width: 1000px; margin: 30px auto; padding: 20px; }
    .card { background: #fff; border-radius: 12px; padding: 20px; margin-bottom: 25px; box-shadow: 0 4px 10px rgba(0,0,0,0.08); }
    .card h2 { font-size: 18px; margin-bottom: 15px; border-bottom: 1px solid #eee; padding-bottom: 8px; text-align:left; }
    table { width: 100%; border-collapse: collapse; font-size: 14px; }
    th { background: #0984e3; color: #fff; padding: 10px; text-align: left; }
    td { padding: 10px; border-bottom: 1px solid #eee; }
    a { text-decoration: none; color: #0984e3; font-weight: 500; }
    .back-link { display:inline-block; margin-bottom:15px; font-size:14px; }
</style>
</head>
<body>
<div class="container">
    <h1>Applicants for <em><?= isset($job['title']) ? htmlspecialchars($job['title']) : 'N/A'; ?></em></h1>
    <a href="admin_dashboard.php" class="back-link">← Back to Dashboard</a>

    <div class="card">
        <h2>Job Details</h2>
        <p><strong>Department:</strong> <?= isset($job['department']) ? htmlspecialchars($job['department']) : 'N/A'; ?></p>
        <p><strong>Salary:</strong> ₱<?= isset($job['salary']) ? number_format((float)$job['salary'], 2) : '0.00'; ?></p>
        <p><strong>Description:</strong> <?= isset($job['description']) ? nl2br(htmlspecialchars($job['description'])) : 'N/A'; ?></p>
        <p><strong>Location:</strong> <?= isset($job['location']) ? htmlspecialchars($job['location']) : 'N/A'; ?></p>
    </div>

    <div class="card">
        <h2>Applicants</h2>
        <?php if ($applicants && $applicants->num_rows > 0): ?>
            <table>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Resume</th>
                    <th>Date Applied</th>
                </tr>
                <?php while ($row = $applicants->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['full_name']); ?></td>
                        <td><?= htmlspecialchars($row['email']); ?></td>
                        <td>
                            <?php if (!empty($row['resume'])): ?>
                                <a href="<?= htmlspecialchars($row['resume']); ?>" target="_blank">View Resume</a>
                            <?php else: ?>
                                N/A
                            <?php endif; ?>
                        </td>
                        <td><?= isset($row['date_applied']) ? htmlspecialchars($row['date_applied']) : 'N/A'; ?></td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php else: ?>
            <p style="color:#888;">No applicants yet.</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
