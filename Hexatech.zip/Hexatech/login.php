<?php
session_start();

// DB connection
$host = "localhost";
$user = "root";
$pass = "";
$dbname = "peso";
$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $role     = isset($_POST['role']) ? $_POST['role'] : '';

    if ($username && $password && $role) {
        $stmt = $conn->prepare("SELECT * FROM users WHERE username=? AND role=? LIMIT 1");
        $stmt->bind_param("ss", $username, $role);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['username'] = $user['username'];
                $_SESSION['role'] = $user['role'];

                if ($role === "admin") {
                    header("Location: admin_post_job.php");
                } else {
                    header("Location: user.php");
                }
                exit;
            } else {
                $message = "❌ Invalid password!";
            }
        } else {
            $message = "❌ Invalid login credentials!";
        }
    } else {
        $message = "❌ Please fill in all fields!";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Login</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    font-family: 'Inter', sans-serif;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    background: #1f1f2e;
    color: #f0f0f0;
}
.container {
    width: 400px;
    padding: 40px 35px;
    background: #2c2c3e;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.6);
    text-align: center;
}
.container h2 {
    font-size: 28px;
    font-weight: 600;
    margin-bottom: 30px;
}
.input-group {
    position: relative;
    margin: 18px 0;
}
.input-group i.left {
    position: absolute;
    top: 50%;
    left: 12px;
    transform: translateY(-50%);
    color: #888;
}
input, select {
    width: 100%;
    padding: 12px 40px;
    border-radius: 8px;
    border: 1px solid #444;
    background: #1f1f2e;
    color: #f0f0f0;
    font-size: 15px;
    outline: none;
    transition: 0.3s;
}
input:focus, select:focus {
    border-color: #5a67f2;
    box-shadow: 0 0 10px rgba(90,103,242,0.5);
}
.show-pass {
    position: absolute;
    top: 50%;
    right: 12px;
    transform: translateY(-50%);
    cursor: pointer;
    color: #888;
}
button {
    width: 100%;
    padding: 12px;
    margin-top: 20px;
    border-radius: 8px;
    border: none;
    background: #5a67f2;
    color: #fff;
    font-size: 16px;
    font-weight: 600;
    cursor: pointer;
    transition: 0.3s;
}
button:hover {
    background: #434fcf;
    box-shadow: 0 5px 15px rgba(90,103,242,0.4);
}
.back-btn {
    display: inline-block;
    margin-top: 15px;
    padding: 10px 16px;
    background: #444;
    color: #fff;
    border-radius: 8px;
    text-decoration: none;
    font-size: 14px;
    transition: 0.3s;
}
.back-btn:hover {
    background: #666;
}
.message {
    margin-top: 15px;
    color: #ff6b6b;
    font-weight: 500;
    font-size: 14px;
}
a {
    color: #ddd;
    display: block;
    text-align: center;
    margin-top: 10px;
    text-decoration: none;
}
a:hover { text-decoration: underline; }
</style>
</head>
<body>

<div class="container">
    <h2>Login</h2>
    <form method="POST">
        <div class="input-group">
            <i class="fas fa-user left"></i>
            <input type="text" name="username" placeholder="Username" required>
        </div>
        <div class="input-group">
            <input type="password" name="password" id="password" placeholder="Password" required>
            <i class="fas fa-eye show-pass" id="togglePass"></i>
        </div>
        <div class="input-group">
            <select name="role" required>
                <option value="">-- Select Role --</option>
                <option value="admin">Admin</option>
                <option value="applicant">Applicant</option>
            </select>
        </div>
        <button type="submit">Login</button>
    </form>
    <p class="message"><?= htmlspecialchars($message) ?></p>
    <a href="register.php">Don’t have an account? Register</a>
    <a href="index.php" class="back-btn"><i class="fas fa-arrow-left"></i> Back</a>
</div>

<script>
const togglePass = document.getElementById('togglePass');
const passwordInput = document.getElementById('password');

togglePass.addEventListener('click', () => {
    if(passwordInput.type === 'password') {
        passwordInput.type = 'text';
        togglePass.classList.replace('fa-eye', 'fa-eye-slash');
    } else {
        passwordInput.type = 'password';
        togglePass.classList.replace('fa-eye-slash', 'fa-eye');
    }
});
</script>

</body>
</html>
